# Lecteur Diaporama 3D — projets Android APK et Windows EXE

Le lecteur HTML original est intégré dans deux enveloppes natives :
- Android : application WebView, avec sélecteur de vidéos du téléphone.
- Windows : application Electron, générant un installateur `.exe` et une version portable `.exe`.

## Construire automatiquement les fichiers APK et EXE (méthode conseillée)
Le dossier contient un workflow GitHub Actions (`.github/workflows/build.yml`).

1. Crée un dépôt GitHub et téléverse tout le contenu de ce dossier.
2. Dans GitHub, ouvre l'onglet **Actions**.
3. Sélectionne **Build Android APK and Windows EXE**, puis **Run workflow**.
4. Attends la fin des deux tâches.
5. Télécharge les résultats dans la section **Artifacts** :
   - `Lecteur-Diaporama-3D-APK` : contient `app-debug.apk`, installable sur Android.
   - `Lecteur-Diaporama-3D-Windows` : contient l'installateur et/ou l'exécutable portable Windows.

Le workflow compile chaque format sur le système adapté (Linux pour Android, Windows pour EXE).
Le APK produit est un APK de débogage signé automatiquement par Android Gradle Plugin, adapté
à l'installation et aux tests. Pour une publication Play Store, il faudra créer une clé de
signature de production et générer un APK/AAB release.

## Construction locale Android
Prérequis : JDK 17, Android SDK (API 35), Gradle 8.9.
Depuis la racine :
    gradle assembleDebug
Résultat : `app/build/outputs/apk/debug/app-debug.apk`

## Construction locale Windows
Sur Windows, avec Node.js 22 :
    cd electron
    npm install
    npm run dist:win
Résultats dans `electron/dist/`.

## Limites reprises du lecteur source
- Les vidéos personnelles sont ouvertes depuis le stockage local et ne sont pas intégrées
  aux fichiers d'installation.
- La génération automatique de sous-titres (Whisper) et leur traduction ne sont pas implémentées
  dans le code d'origine ; l'application conserve donc le message d'attente pour les vidéos importées.
- Le lecteur est fourni comme emballage natif de l'interface HTML existante, pas comme moteur vidéo
  natif entièrement réécrit.
